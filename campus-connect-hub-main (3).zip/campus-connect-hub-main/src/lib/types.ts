export type UserRole = "student" | "organizer" | "admin";

export type Language = "en" | "gu" | "hi";

export interface UserProfile {
  id: string;
  name: string;
  rollNo: string;
  email: string;
  role: UserRole;
  department: string;
  semester: number;
  avatar: string;
  points: number;
  streakDays: number;
  volunteerHours: number;
  attendanceRate: number; // percentage, e.g. 86
  badges: string[]; // Badge IDs
}

export type EventCategory = 
  | "Tech" 
  | "Culture" 
  | "Sports" 
  | "Leadership" 
  | "Academic" 
  | "Career" 
  | "Workshop";

export type EventStatus = "upcoming" | "live" | "completed" | "cancelled" | "pending_approval" | "rejected";

export interface CampusEvent {
  id: string;
  title: string;
  description: string;
  category: EventCategory;
  department: string; // e.g., "Computer Science", "All Departments"
  date: string; // YYYY-MM-DD
  time: string; // e.g. "10:00 AM - 01:00 PM"
  venue: string;
  organizerName: string;
  organizerEmail: string;
  capacity: number;
  registeredCount: number;
  waitlistCount: number;
  approvalRequired: boolean;
  isTeamEvent: boolean;
  minTeamSize?: number;
  maxTeamSize?: number;
  volunteerHoursReward?: number;
  bannerImage: string;
  status: EventStatus;
  currentQrToken?: string;
  qrExpiresAt?: number; // timestamp
  averageRating?: number;
  reviewCount?: number;
  rules?: string[];
  requireLiveLocation?: boolean;
  venueLatitude?: number; // GSFC University coordinates e.g. 22.3685
  venueLongitude?: number; // e.g. 73.1895
  allowedRadiusMeters?: number; // default 350m
  certificatesReleased?: boolean; // Admin release grant
}

export interface TeamMember {
  name: string;
  rollNo: string;
  email: string;
}

export interface Registration {
  id: string;
  eventId: string;
  userId: string;
  userRollNo: string;
  userName: string;
  department: string;
  registeredAt: string;
  status: "confirmed" | "waitlisted" | "pending_approval" | "rejected" | "attended" | "punched_in" | "punched_out";
  isTeam: boolean;
  teamName?: string;
  teamMembers?: TeamMember[];
  punchInTime?: string;
  punchOutTime?: string;
  punchInLocation?: { latitude: number; longitude: number; distanceMeters: number; verified: boolean };
  punchOutLocation?: { latitude: number; longitude: number; distanceMeters: number; verified: boolean };
  certificateUnlocked?: boolean;
}

export interface AttendanceRecord {
  id: string;
  eventId: string;
  eventTitle: string;
  userId: string;
  userName: string;
  userRollNo: string;
  department: string;
  timestamp: string;
  punchInTime?: string;
  punchOutTime?: string;
  verifiedMethod: "qr_scan" | "manual_admin" | "offline_sync" | "live_punch" | "unified_otp_barcode";
  tokenUsed: string;
  synced: boolean;
  certificateId?: string;
  certificateUnlocked?: boolean;
  userLatitude?: number;
  userLongitude?: number;
  distanceFromVenueMeters?: number;
  locationVerified?: boolean;
  mobileNumber?: string;
  otpVerified?: boolean;
  barcodeScanned?: boolean;
  barcodeValue?: string;
  vehicleId?: string;
  vehicleNumber?: string;
}

export type VehicleType = "2_wheeler" | "4_wheeler" | "ev" | "commercial";

export interface VehicleRecord {
  id: string;
  vehicleNumber: string; // e.g. GJ-06-AB-1234
  vehicleType: VehicleType;
  ownerType: "student" | "faculty" | "visitor";
  ownerName: string;
  ownerContact: string;
  ownerRollOrVisitorId: string;
  parkingBay: string; // e.g. "Zone A - South Gate", "Zone B - Student Parking", "VIP Bay - Admin Block"
  entryTime: string;
  exitTime?: string;
  status: "parked" | "exited";
  gatePassId: string;
  verifiedBy: string;
}

export interface VisitorRecord {
  id: string; // e.g. VIS-2026-00125
  fullName: string;
  mobile: string;
  email?: string;
  organization: string; // e.g. "Tata Consultancy Services", "L&T Ltd.", "Guest Speaker"
  purpose: "Campus Event Attendance" | "Placement & Industry Meeting" | "Guest Lecture / Workshop" | "Official Campus Visit" | "Vendor / Contractor";
  personToMeet: string; // e.g. "Prof. Rajiv Mehta (TPC)", "Dr. Ananya Sharma (Dean)", "Dr. Suresh Rao"
  departmentToMeet: string;
  idProofType: "Aadhaar Card" | "Driving License" | "Voter ID / Gov ID" | "Corporate Work ID" | "Passport";
  idProofNumber?: string;
  otpVerified: boolean;
  otpVerifiedAt?: string;
  locationVerified: boolean;
  userLatitude?: number;
  userLongitude?: number;
  distanceMeters?: number;
  entryTime: string;
  exitTime?: string;
  status: "active" | "exited";
  hasVehicle: boolean;
  vehicleId?: string;
  vehicleNumber?: string;
  vehicleType?: VehicleType;
  qrPassCode: string;
  assignedEventId?: string;
  assignedEventTitle?: string;
}

export interface PendingCheckin {
  id: string;
  eventId: string;
  eventTitle: string;
  userId: string;
  userRollNo: string;
  userName: string;
  department: string;
  timestamp: string;
  token: string;
  retryCount: number;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: "attendance" | "engagement" | "leadership" | "volunteer";
  unlocked: boolean;
  earnedDate?: string;
  xpBonus: number;
}

export interface EventFeedback {
  id: string;
  eventId: string;
  userId: string;
  userName: string;
  userRollNo?: string;
  rating: number; // 1 to 5
  comment: string;
  createdAt: string;
}

export interface EventBroadcast {
  id: string;
  eventId: string;
  eventTitle: string;
  authorName: string;
  message: string;
  priority: "high" | "normal" | "urgent";
  createdAt: string;
}

export interface ActivityPointsCategory {
  earned: number;
  max: number;
  color: string;
  label: string;
  iconName: string;
}

export interface ActivityPointsBreakdown {
  technical: ActivityPointsCategory;
  cultural: ActivityPointsCategory;
  sports: ActivityPointsCategory;
  social: ActivityPointsCategory;
  totalEarned: number;
  totalMax: number;
  percentage: number;
}

export interface NotificationItem {
  id: string;
  userId?: string; // empty means all or role-specific
  title: string;
  message: string;
  type: "reminder" | "approval" | "alert" | "achievement" | "sync";
  timestamp: string;
  read: boolean;
  eventId?: string;
}

export interface AuditLogEntry {
  id: string;
  action: string;
  performedBy: string;
  target: string;
  timestamp: string;
  details: string;
}

// ==========================================
// CAMPUS PLATFORM 360 EXTENSIONS
// ==========================================

export type ClubCategory = "Technical" | "Cultural" | "Sports" | "Social & NSS" | "Entrepreneurship" | "Literary";

export interface Club {
  id: string;
  name: string;
  category: ClubCategory;
  department: string;
  description: string;
  bannerImage: string;
  logo: string;
  facultyCoordinator: {
    name: string;
    email: string;
    department: string;
  };
  studentLead: {
    name: string;
    rollNo: string;
    email: string;
  };
  memberCount: number;
  meetingSchedule: string;
  foundedYear: number;
  status: "active" | "recruiting" | "inactive";
  tags: string[];
}

export interface ClubMember {
  id: string;
  clubId: string;
  userId: string;
  userName: string;
  userRollNo: string;
  department: string;
  role: "member" | "committee" | "lead" | "coordinator";
  joinedAt: string;
  status: "active" | "pending_approval";
  volunteerHoursEarned: number;
}

export interface ClubActivity {
  id: string;
  clubId: string;
  clubName: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  description: string;
  isPublicEvent: boolean;
  attendanceCount: number;
}

export interface VerifiedAchievement {
  id: string;
  userId: string;
  userName: string;
  userRollNo: string;
  title: string;
  category: "technical" | "hackathon" | "cultural" | "sports" | "leadership" | "volunteering";
  eventOrActivityName: string;
  issuingAuthority: string;
  dateEarned: string;
  certificateId?: string;
  verificationHash: string;
  qrCodePayload: string;
  verifiedBy: string;
  badgeIcon: string;
  description: string;
}

export interface CampusAnnouncement {
  id: string;
  title: string;
  content: string;
  category: "university" | "department" | "club" | "placement" | "emergency";
  authorName: string;
  authorRole: string;
  departmentTarget?: string; // "all" or specific
  priority: "normal" | "important" | "emergency";
  createdAt: string;
  expiresAt?: string;
  readBy: string[]; // user IDs
}

export interface CampusService {
  id: string;
  name: string;
  category: "academic" | "administrative" | "facility" | "student_support" | "emergency";
  location: string;
  roomNumber: string;
  building: string;
  openingHours: string;
  headPerson: string;
  contactEmail: string;
  contactPhone: string;
  description: string;
  iconName: string;
}

export interface DigitalStudentIdCard {
  rollNo: string;
  name: string;
  program: string;
  department: string;
  semester: number;
  validTill: string;
  bloodGroup: string;
  qrVerificationCode: string;
  barcode: string;
  photoUrl: string;
  status: "active" | "suspended" | "expired";
}

export interface NewRegisteredStudent {
  id: string;
  fullName: string;
  mobileNumber: string;
  rollNo: string;
  email: string;
  school: string;
  department: string;
  degree: string;
  semester: number;
  residenceType: "hostel" | "dayscholar";
  hostelBlockOrBusRoute?: string;
  clubsInterested: string[];
  idCardUploaded: boolean;
  isLocked: boolean;
  verifiedByUniversity: boolean;
  createdAt: string;
}

export interface AssistantMessage {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
  suggestions?: string[];
  actionLink?: { label: string; view: string; eventId?: string };
}


